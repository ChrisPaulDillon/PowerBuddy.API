﻿namespace PowerLifting.Entity.System.ExerciseMuscleGroups.DTOs
{
    public class ExerciseMuscleGroupDTO
    {
        public int ExerciseMuscleGroupId { get; set; }
        public string ExerciseMuscleGroupName { get; set; }
    }
}