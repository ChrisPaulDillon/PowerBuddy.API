﻿namespace PowerLifting.Entity.System.ExerciseTypes.DTOs
{
    public class ExerciseTypeDTO
    {
        public int ExerciseTypeId { get; set; }
        public string ExerciseTypeName { get; set; }
    }
}