﻿namespace PowerLifting.Service.TemplatePrograms.Model
{
    public enum WeightProgressionTypeEnum
    {
        PERCENTAGE,
        INCREMENTAL
    }
}
