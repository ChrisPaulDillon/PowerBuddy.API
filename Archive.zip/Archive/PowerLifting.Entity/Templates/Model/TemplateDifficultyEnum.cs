﻿namespace PowerLifting.Service.TemplatePrograms.Model
{
    public enum TemplateDifficultyEnum
    {
        BEGINNER,
        INTERMEDIATE,
        ADVANCED
    }
}
