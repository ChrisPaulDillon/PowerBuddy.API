﻿namespace PowerLifting.Service.TemplatePrograms.Model
{
    public enum RepSchemeTypeEnum
    {
       FIXED = 0,
       RAMPED = 1
    }
}
