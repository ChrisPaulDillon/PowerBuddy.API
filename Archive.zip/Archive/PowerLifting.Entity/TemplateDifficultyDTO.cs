﻿using System;
namespace PowerLifting.Service.SystemServices.TemplateDifficultys.DTO
{
    public class TemplateDifficultyDTO
    {
        public int TemplateDifficultyId { get; set; }
        public string TemplateDifficultyName { get; set; }
    }
}
