﻿using System;
namespace PowerLifting.Service.SystemServices.RepSchemeTypes.Model
{
    public class RepSchemeType
    {
        public int RepSchemeTypeId { get; set; }
        public string RepSchemeName { get; set; }
    }
}
