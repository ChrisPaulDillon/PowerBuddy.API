﻿using System;
namespace PowerLifting.Service.SystemServices.TemplateDifficultys.Model
{
    public class TemplateDifficulty
    {
        public int TemplateDifficultyId { get; set; }
        public string TemplateDifficultyName { get; set; }
    }
}
