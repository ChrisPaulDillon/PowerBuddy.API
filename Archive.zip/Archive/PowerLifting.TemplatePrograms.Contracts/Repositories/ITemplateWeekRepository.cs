﻿namespace PowerLifting.TemplatePrograms.Contracts.Repositories
{ 
    public interface ITemplateWeekRepository
    {
    }
}